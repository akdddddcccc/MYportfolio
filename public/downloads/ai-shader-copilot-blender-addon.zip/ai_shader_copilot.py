bl_info = {
    "name": "AI Shader Copilot",
    "author": "Muyang",
    "version": (0, 1, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Shader Copilot",
    "description": "Creates editable industrial and stylized material node templates",
    "category": "Material",
}

import bpy


MATERIALS = {
    "ALUMINUM": ("AI_Anodized_Aluminum", (0.08, 0.1, 0.12, 1.0), 0.92, 0.28),
    "POLYMER": ("AI_Soft_Touch_Polymer", (0.42, 0.35, 0.3, 1.0), 0.02, 0.66),
    "GLASS": ("AI_Frosted_Glass", (0.35, 0.55, 0.72, 1.0), 0.04, 0.18),
    "TOON": ("AI_Cel_Shaded_Coating", (0.72, 0.32, 0.24, 1.0), 0.0, 0.46),
}


def clear_nodes(nodes):
    nodes.clear()


def add_principled(nodes, links, color, metallic, roughness):
    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (560, 0)
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (270, 0)
    bsdf.inputs["Base Color"].default_value = color
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = roughness
    links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])
    return bsdf, output


def add_micro_surface(nodes, links, bsdf, scale=90.0, strength=0.12):
    noise = nodes.new("ShaderNodeTexNoise")
    noise.location = (-420, -80)
    noise.inputs["Scale"].default_value = scale
    noise.inputs["Detail"].default_value = 3.0
    bump = nodes.new("ShaderNodeBump")
    bump.location = (-100, -80)
    bump.inputs["Strength"].default_value = strength
    bump.inputs["Distance"].default_value = 0.04
    links.new(noise.outputs["Fac"], bump.inputs["Height"])
    links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])


def build_material(kind):
    name, color, metallic, roughness = MATERIALS[kind]
    material = bpy.data.materials.new(name)
    material.use_nodes = True
    nodes = material.node_tree.nodes
    links = material.node_tree.links
    clear_nodes(nodes)

    if kind == "TOON":
        output = nodes.new("ShaderNodeOutputMaterial")
        output.location = (560, 0)
        diffuse = nodes.new("ShaderNodeBsdfDiffuse")
        diffuse.location = (220, 0)
        diffuse.inputs["Color"].default_value = color
        shader_to_rgb = nodes.new("ShaderNodeShaderToRGB")
        shader_to_rgb.location = (-10, 0)
        ramp = nodes.new("ShaderNodeValToRGB")
        ramp.location = (-220, 0)
        ramp.color_ramp.interpolation = "CONSTANT"
        ramp.color_ramp.elements[0].color = (0.08, 0.12, 0.18, 1)
        ramp.color_ramp.elements[1].color = color
        emission = nodes.new("ShaderNodeEmission")
        emission.location = (350, 0)
        links.new(diffuse.outputs["BSDF"], shader_to_rgb.inputs["Shader"])
        links.new(shader_to_rgb.outputs["Color"], ramp.inputs["Fac"])
        links.new(ramp.outputs["Color"], emission.inputs["Color"])
        links.new(emission.outputs["Emission"], output.inputs["Surface"])
    else:
        bsdf, _ = add_principled(nodes, links, color, metallic, roughness)
        if kind == "GLASS":
            bsdf.inputs["Transmission Weight"].default_value = 0.72
            bsdf.inputs["IOR"].default_value = 1.45
            volume = nodes.new("ShaderNodeVolumeAbsorption")
            volume.location = (270, -200)
            volume.inputs["Color"].default_value = color
            volume.inputs["Density"].default_value = 0.12
            output = next(node for node in nodes if node.bl_idname == "ShaderNodeOutputMaterial")
            links.new(volume.outputs["Volume"], output.inputs["Volume"])
        else:
            add_micro_surface(nodes, links, bsdf, 180.0 if kind == "ALUMINUM" else 70.0, 0.07 if kind == "ALUMINUM" else 0.13)
    return material


class SHADERCOPILOT_OT_create(bpy.types.Operator):
    bl_idname = "shader_copilot.create_material"
    bl_label = "Create editable material"
    bl_options = {"REGISTER", "UNDO"}

    material_kind: bpy.props.EnumProperty(
        name="Material",
        items=[(key, label[0].replace("AI_", "").replace("_", " ").title(), "") for key, label in MATERIALS.items()],
        default="ALUMINUM",
    )

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.type != "MESH":
            self.report({"ERROR"}, "Select a mesh object first")
            return {"CANCELLED"}
        material = build_material(self.material_kind)
        if obj.data.materials:
            obj.data.materials[0] = material
        else:
            obj.data.materials.append(material)
        self.report({"INFO"}, f"Created {material.name}")
        return {"FINISHED"}


class SHADERCOPILOT_PT_panel(bpy.types.Panel):
    bl_label = "AI Shader Copilot"
    bl_idname = "SHADERCOPILOT_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Shader Copilot"

    def draw(self, context):
        layout = self.layout
        layout.label(text="Editable material templates")
        layout.label(text="Select a mesh, then generate:")
        for kind in MATERIALS:
            op = layout.operator("shader_copilot.create_material", text=MATERIALS[kind][0].replace("AI_", "").replace("_", " ").title())
            op.material_kind = kind


classes = (SHADERCOPILOT_OT_create, SHADERCOPILOT_PT_panel)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
